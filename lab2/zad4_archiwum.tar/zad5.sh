#! usr/bin/bash

#aby skrypt działał poprawnie trzeba ustawić serwer STMP
#sudo apt-get install sstmp
#ustawic maila i haslo w pliku /etc/sstmp/sstmp.conf

while IFS= read -r line;
do
    echo "sendmail "$line" < mail.txt" #sprawdzenie czy komenda jest poprawna tak aby nie wysylac
    # sendmail "$line" < mail.txt
done < adresy.txt